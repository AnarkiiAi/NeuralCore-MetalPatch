"""Actual Apple MLX array regression, not a full Qwen/Metal-object leak certification."""
import argparse, ast, hashlib, json, platform, resource, sys, time, traceback
from pathlib import Path
import mlx.core as mx
import numpy as np
ROOT=Path(__file__).resolve().parent
class _BaseCache: pass

def load(path):
    text=path.read_text(encoding='utf-8')
    tree=ast.parse(text)
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ArraysCache')
    module=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]))
    scope={'mx':mx,'_BaseCache':_BaseCache,'Optional':__import__('typing').Optional,'List':__import__('typing').List}
    exec(compile(module,str(path),'exec'),scope)
    return scope['ArraysCache']

def materialize(x):
    if x is None:return None
    mx.eval(x)
    return np.array(x.tolist())

def compare(a,b):
    for name in ('lengths','left_padding'):
        x,y=materialize(getattr(a,name)),materialize(getattr(b,name))
        if x is None or y is None:
            assert x is None and y is None,(name,'None mismatch')
        else:np.testing.assert_array_equal(x,y,err_msg=name)
    x,y=materialize(a.make_mask(16)),materialize(b.make_mask(16))
    if x is None or y is None:assert x is None and y is None
    else:np.testing.assert_array_equal(x,y)

def pair(Old,New):
    a,b=Old(2,[1,3]),New(2,[1,3])
    for c in (a,b):c.prepare([9,7])
    return a,b

def main(iterations):
    Old=load(ROOT/'cache.upstream.py'); New=load(ROOT/'cache.patched.py')
    results=[]
    def test(name,fn):
        start=time.perf_counter()
        try:fn();results.append({'name':name,'status':'PASS','seconds':round(time.perf_counter()-start,4)})
        except Exception as e:
            results.append({'name':name,'status':'FAIL','seconds':round(time.perf_counter()-start,4),'error':repr(e),'trace':traceback.format_exc()})
        print(name,results[-1]['status'],flush=True)
    def interleaved():
        a,b=pair(Old,New)
        for i in range(40):
            compare(a,b);a.advance(i%3+1);b.advance(i%3+1)
        compare(a,b)
    def filter_case():
        a,b=pair(Old,New)
        for c in (a,b):c.advance(3);c.filter([1])
        compare(a,b)
    def extend_case():
        a,b=pair(Old,New);c,d=pair(Old,New)
        for x in (a,b,c,d):x.advance(2)
        a.extend(c);b.extend(d);compare(a,b)
    def state_case():
        a,b=pair(Old,New)
        for c in (a,b):c.advance(2)
        aa,bb=Old(2),New(2)
        aa.state=a.state;bb.state=b.state
        compare(aa,bb)
    def setters():
        a,b=pair(Old,New)
        for c in (a,b):
            c.advance(2);c.lengths=mx.array([5,4]);c.left_padding=mx.array([1,0])
        compare(a,b)
    def long_case():
        a,b=pair(Old,New)
        for i in range(iterations):
            a.advance(1);b.advance(1)
            if i%100==0:compare(a,b)
        compare(a,b)
    for name,fn in [('interleaved',interleaved),('filter',filter_case),('extend',extend_case),('state_roundtrip',state_case),('setters',setters),('repeated_advances',long_case)]:test(name,fn)
    report={'platform':platform.platform(),'iterations':iterations,'python':sys.version,'mlx_version':getattr(mx,'__version__','not_exposed'),'source_sha256':hashlib.sha256((ROOT/'cache.upstream.py').read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256((ROOT/'cache.patched.py').read_bytes()).hexdigest(),'max_rss_raw':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'metal_object_count':'NOT MEASURED','results':results}
    out=ROOT/'logs'/f'results_{int(time.time())}.json';out.write_text(json.dumps(report,indent=2))
    print('Report:',out,'Failures:',sum(x['status']=='FAIL' for x in results))
    return int(any(x['status']=='FAIL' for x in results))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--iterations',type=int,default=2000)
    args=p.parse_args()
    if args.iterations<1:raise SystemExit('iterations must be positive')
    sys.exit(main(args.iterations))
