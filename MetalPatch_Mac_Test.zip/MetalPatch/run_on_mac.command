#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
LOG="logs/metalpatch_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1
echo "NeuralCore MetalPatch | $(date -u)"
echo "macOS: $(sw_vers -productVersion) | CPU: $(uname -m)"
if [[ "$(uname -m)" != "arm64" ]]; then
  echo "NO-GO: MLX requires Apple Silicon. Intel iMacs cannot execute this test."
  exit 2
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "NO-GO: Install Python 3 from python.org or Homebrew first."
  exit 3
fi
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --disable-pip-version-check mlx numpy
python -m pip freeze > "logs/dependencies_$(date +%Y%m%d_%H%M%S).txt"
python test_mlx_cache.py --iterations "${1:-2000}"
echo "Finished. Review logs; passing tests do not certify the Qwen leak fixed."
