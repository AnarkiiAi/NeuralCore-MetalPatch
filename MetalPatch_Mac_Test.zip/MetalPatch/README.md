# NeuralCore MetalPatch | Apple Silicon test kit

Experimental patch only. NOT production-approved. Zero-cost local testing (internet may be required to download free Python packages).

## Supported hardware
Apple Silicon Mac (M1/M2/M3/M4/M5), including Apple Silicon iMacs. Intel iMacs are NOT supported for MLX testing.

## How to run on Mac
1. Transfer `MetalPatch_Mac_Test.zip` to the Mac and extract it.
2. Open Terminal and enter the extracted MetalPatch directory.
3. Run `chmod +x run_on_mac.command` once if necessary.
4. Run `./run_on_mac.command` (default 2,000 advances).
5. For extended testing, run `./run_on_mac.command 20000` after the short test succeeds.
6. Keep the `logs` directory and send the JSON report and terminal log back for review.

The launcher creates an isolated `.venv`, installs free `mlx` and `numpy`, logs exact dependency versions, then executes the pinned upstream and patched `ArraysCache` class definitions with actual MLX arrays. It does NOT load Qwen3.5-397B or require hundreds of gigabytes of RAM.

## Safety and scientific limits
- This is a class-level test on real Apple MLX; it does not instrument Metal buffer-object counts or demonstrate the original batched decoding crash has been fixed.
- The original long-decode bug may only reproduce through the full batched generation path.
- Do not install the patched source into your global MLX-LM environment. The kit loads both class bodies in isolation.
- The baseline may accumulate lazy operations or fail in long tests. Failures are retained in the report.
- Tests should be run with other heavy apps closed, but there is no need to alter macOS security settings globally.
- Requires Python 3 and internet access for initial installation unless dependencies already cached.
- Model compatibility and performance on an M5 Ultra remain unverified.

Pinned upstream commit: ba8a08fd2ed72bbc53de84f89933f91fe4743e4a
